Marc-Eric Schneider, 4500427

Die Projektmappe liegt im Ordner "build/vs2012" hei�t curves